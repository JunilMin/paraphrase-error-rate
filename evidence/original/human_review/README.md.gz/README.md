# Paraphrase review

Two different people independently rated the same 600 pairs from 200 source
examples, according to the author's confirmation. Their original submitted files
are preserved byte for byte as reviewer_1.csv and reviewer_2.csv. Review dates,
reviewer qualifications, time spent, and whether reviewers saw model outcomes
were not recorded here. The sampling metadata in sample.json describe a uniform
source-example sample excluding sources in the earlier preparation review.

For meaning preservation, reviewer 1 assigned yes/no/uncertain to 434/85/81 pairs;
reviewer 2 assigned 506/29/65. Exact agreement was 412/600 (68.67%); nominal
Cohen's kappa was 0.149744. Both assigned label_preserved=yes to all 600 pairs.
Label agreement is 100%; kappa is undefined because both marginal distributions
contain only one category. Category preservation is not semantic equivalence.

The 188 disagreements and 12 joint uncertain ratings were considered by an AI
assistant. All 200 rows in assistant_adjudication_200.csv explicitly remain
pending_human_confirmation and are not two-reviewer consensus. Combined with
the 400 determinate human agreements, the supplementary AI-assisted table has
429 yes, 98 no, and 73 uncertain meaning judgments. Those are not final human
quality estimates. The independent human ratings are the primary quality data.

Recompute the summaries without a GPU or additional Python packages:

```bat
python src/review_analysis.py
```

Outputs are in analysis/: independent_ratings_summary.csv,
meaning_confusion_matrix.csv, ai_assisted_labels_600.csv, and summary.json.
No frozen paraphrases, PER scores, trained checkpoints, or model outcomes are
changed. Earlier drafts with final/consensus field names were removed from this review copy.
They remain in the original archive and were never jointly confirmed human ratings.

The three paraphrases within each source are correlated. These 600 pairs are not
600 independent source examples. This is a post-experiment sample assessment,
not exhaustive validation of the 22,800-candidate bank. No source or paraphrase
is silently removed from the experiment because of these judgments.
