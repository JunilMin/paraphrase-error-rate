# Frozen-bank experiment outputs

The original model results and PER analyses are unchanged. Quality metadata are
copied from results/paraphrase_quality.json. Two independent human reviewers
rated a 600-pair sample; meaning agreement was 68.67% (kappa 0.150). Separate
AI-assisted resolutions of 200 pairs remain pending human confirmation and are
not human consensus. The full bank has not been validated for semantic equivalence.
See results/human_review/README.md for the original ratings and reproduction.
